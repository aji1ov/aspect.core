<?php

namespace Aspect\Component;

use CBitrixComponent;

class AspectUiTableComponent extends CBitrixComponent {

    public function executeComponent(): void
    {
        $this->includeComponentTemplate('table');
    }

}