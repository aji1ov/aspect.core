
<div class="adm-toolbar-panel-container">
    <div class="adm-toolbar-panel-flexible-space">
        <?php
        $APPLICATION->IncludeComponent(
            'bitrix:main.ui.filter',
            '',
            $arParams['FILTER']
        );
        ?>
    </div>
    <div class="adm-toolbar-panel-align-right">
        <?php foreach ($arParams['~BUTTONS'] as $button) {
            echo $button;
        }?>
    </div>
</div>
<?php


$APPLICATION->includeComponent(
    "bitrix:main.ui.grid",
    "",
    $arParams['GRID']
);