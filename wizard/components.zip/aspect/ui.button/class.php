<?php

namespace Aspect\Component;

use CBitrixComponent;

class AspectUiButtonComponent extends CBitrixComponent {

    public function executeComponent(): void
    {
        $this->includeComponentTemplate('button');
    }

}