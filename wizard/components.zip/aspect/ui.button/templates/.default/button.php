<button
        class="ui-btn ui-btn-<?=$arParams['COLOR'] ?? 'light-border'?>"
        <?php if($arParams['HANDLER']) {?>onclick="<?=$arParams['HANDLER']?>"<?php }?>>
    <?=$arParams['TITLE']?>
</button>