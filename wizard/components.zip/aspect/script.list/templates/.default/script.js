class AspectScriptList {
    new(view) {
        BX.UI.Dialogs.MessageBox.show({
            message: view,
            buttons: BX.UI.Dialogs.MessageBoxButtons.OK_CANCEL,
            popupOptions: {
                bindElement: BX("yesnocancel"),
                offsetLeft: 20,
                closeIcon: true,
                events: {
                    onPopupClose: function() {
                        BX.UI.Dialogs.MessageBox.alert("Попап закрыт.");
                    }
                }
            }
        });
    }
}

window.aspectScriptList = new AspectScriptList();