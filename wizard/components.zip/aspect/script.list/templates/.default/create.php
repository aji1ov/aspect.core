<div class="ui-ctl ui-ctl-textbox ui-ctl-block">
    <div class="ui-ctl-tag">Название нового скрипта</div>
    <input type="text" class="ui-ctl-element" name="name">
</div>