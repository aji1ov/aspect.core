<?php

namespace Aspect\Component;

use Aspect\Lib\Exception\CommandException;
use Aspect\Lib\Preset\Command\Script\Create;
use Aspect\Lib\Preset\Command\Script\Delete;
use Aspect\Lib\Render\ControllerView;
use Bitrix\Main\Engine\Controller;
use ReflectionException;

class AspectScriptListController extends Controller
{

    public function configureActions()
    {
        return [
            'getCreateForm' => [
                'prefilters' => []
            ],
            'create' => [
                'prefilters' => []
            ],
            'remove' => [
                'prefilters' => []
            ]
        ];
    }

    /**
     * @throws ReflectionException
     * @throws CommandException
     */
    public function createAction(string $name): void
    {
        command(Create::class, ['name' => $name]);
    }

    /**
     * @throws ReflectionException
     * @throws CommandException
     */
    public function removeAction(string $name): void
    {

        command(Delete::class, ['name' => $name]);
    }

    public function getCreateFormAction(string $template, ?array $argumentMap = null): array
    {
        return [
            'html' => ControllerView::get('aspect:script.list')
                ->setTemplate($template)
                ->setComponentParams($argumentMap ?: [])
                ->setView('create')
                ->render()
        ];
    }
}