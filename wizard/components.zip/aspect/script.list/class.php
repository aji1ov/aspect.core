<?php

namespace Aspect\Component;

use Aspect\Lib\Ajax\ComponentAction;
use Aspect\Lib\Ajax\Dialog;
use Aspect\Lib\Ajax\ExtensionFunction;
use Aspect\Lib\Ajax\JsExpression;
use Aspect\Lib\Ajax\Redirect;
use Aspect\Lib\Ajax\Reload;
use Aspect\Lib\Facade\Yakov;
use Aspect\Lib\Manager\ScriptManager;
use Aspect\Lib\Repository\ScriptTable;
use Aspect\Lib\UI\Connector\ConnectorInterface;
use Aspect\Lib\UI\Connector\OrmConnector;
use Aspect\Lib\UI\Table;
use Bitrix\Main\Grid\Context;
use CBitrixComponent;
use Exception;

class AspectScriptListComponent extends CBitrixComponent
{

    /**
     * @throws Exception
     */
    public function createTable(): Table
    {
        $table = new Table(static::class);

        $table->buttons(
            Table\Button::make('Новый скрипт')
                ->primary()
                ->onClick(fn () => ExtensionFunction::invoke('aspect.script', 'newScriptAction', $this->getTemplateName()))
        );

        $table->columns(
            Table\Column::make('NAME')
                ->title('Имя скрипта')
                ->filter(Table\Filter::text())
                ->sort(),

            Table\Column::make('IS_RUNNING')
                ->title('Выполняется')
                ->sort('RUNNING')
                ->filter(Table\Filter::checkbox('RUNNING'))
                ->render(fn (array $row) => $row['RUNNING'] ? 'Да' : 'Нет'),

            Table\Column::make('IS_CANCELED')
                ->title('Отменнен')
                ->filter(Table\Filter::checkbox('CANCELLED'))
                ->render(fn (array $row) => $row['CANCELLED'] ? 'Да' : 'Нет'),

            Table\Action::make('VIEW')
                ->title('Посмотреть')
                ->render(fn (array $row) => new Redirect('/bitrix/admin/aspect_script_view.php?script='.$row['NAME'])),

            Table\Action::make('REMOVE')
                ->title('Удалить')
                ->render(fn (array $row) => ComponentAction::call(
                    'aspect:script.list',
                    'ajax',
                    'remove',
                    ['name' => $row['NAME']],
                    new Reload()
                ))
        );

        $table->navigator(
            Table\Navigator::make()
                ->showTotal()
                ->paginate(5, 10, 50, 100, 500)
        );
        $table->connect($this->createConnector());

        return $table;
    }

    /**
     * @throws Exception
     */
    public function createConnector(): ConnectorInterface
    {
        $filterNames = [];

        $scriptsPath = Yakov::getCmdBundlesPath();

        foreach (glob($scriptsPath."/*.php") as $name) {

            $scriptName = str_replace(".php", "", str_replace($scriptsPath."/", "", $name));
            $scriptManager = ScriptManager::getInstance();

            if (!$scriptManager->get($scriptName)) {
               $scriptManager->index($scriptName);
            }

            $filterNames[] = $scriptName;
        }

        $connector = new OrmConnector(ScriptTable::class);
        $connector->filter(['NAME' => $filterNames]);

        return $connector;
    }

    /**
     * @throws Exception
     */
    public function executeComponent(): void
    {
        if (Context::isInternalRequest()) {
            global $APPLICATION;
            $APPLICATION->RestartBuffer();
        }

        $this->arResult['TABLE'] = $this->createTable()->render();
        $this->includeComponentTemplate("template");
    }
}