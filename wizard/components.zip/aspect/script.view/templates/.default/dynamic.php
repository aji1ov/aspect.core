<?php


$running = $arResult['RUNNING'] && !$arResult['CANCELLED'];
$cancelled = $arResult['RUNNING'] && $arResult['CANCELLED'];

$created = $arResult['CREATED'] && !$running && !$cancelled;

$inProcess = $created || $running || $cancelled;

?>

<div class="aspect-code__action adm-toolbar-panel-container">
    <div class="adm-toolbar-panel-flexible-space">


        <?php if ($inProcess) { ?>

            <div class="ui-btn-base ui-btn-split <?=($created ? 'ui-btn-clock' : '')?>">
                <button class="ui-btn-main disabled"
                        disabled
                        data-hint="Скрипт будет выполнен через Очередь задач"
                        data-hint-no-icon data-hint-interactivity
                        onclick="aspectScriptViewController.action.make()">

                    <?php if($running) {?>
                        <div class="ui-label ui-label-fill ui-label-warning"><span class="ui-label-inner">Исполняется</span></div>
                    <?php } else if($cancelled) {?>
                        <div class="ui-label ui-label-fill ui-label-danger"><span class="ui-label-inner">Прерывается</span></div>
                    <?php }?>
                    Выполнить
                </button>
                <button onclick="BX.adminList.ShowMenu(this, [{'HTML':'Перезапустить','ONCLICK':'aspectScriptViewController.action.remake()'}]);"
                        class="ui-btn-extra adm-list-table-popup-active"></button>
            </div>

        <?php } else { ?>

            <button class="ui-btn-main ui-btn-success" data-hint="Скрипт будет выполнен через Очередь задач"
                    data-hint-no-icon data-hint-interactivity onclick="aspectScriptViewController.action.make()">
                Выполнить
            </button>

        <?php } ?>

        <?php if ($running || $created) { ?>
            <button class="ui-btn ui-btn-danger"
                    data-hint="Скрипт будет пренудительно остановлен или снят с очереди задач" data-hint-no-icon
                    data-hint-interactivity onclick="aspectScriptViewController.action.interrupt()">Остановить выполнение
            </button>
        <?php } ?>


    </div>

    <div class="adm-toolbar-panel-align-center">
        <button class="ui-btn ui-btn-light-border"
                data-hint="Скрипт будет пренудительно выполнен как AJAX запрос" data-hint-no-icon
                data-hint-interactivity onclick="aspectScriptViewController.action.exec()">Выполнить сейчас
        </button>
    </div>

</div>

<div class="aspect-code__output">
    <label class="adm-detail-title" for="output">Результат выполнения скрипта</label>
    <textarea id="output" name="output" readonly disabled rows="15" wrap="OFF"
              style="width:100%;resize: none"><?= $arResult['OUTPUT'] ?></textarea>
</div>