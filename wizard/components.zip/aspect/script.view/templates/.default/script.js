class AspectScriptViewAction {

    #scriptName;
    #afterRequest;

    constructor(scriptName, controller) {
        this.controller = controller;

        this.#scriptName = scriptName;
        this.#afterRequest = (response) => {
            this.controller.updateView(response.html);
        }
    }

    make() {
        this
            .#request('make', {scriptName: this.#scriptName, code: this.controller.code})
            .then(this.#afterRequest);
    }

    remake() {
        this
            .#request('remake', {scriptName: this.#scriptName, code: this.controller.code})
            .then(this.#afterRequest);
    }

    interrupt() {
        this
            .#request('interrupt', {scriptName: this.#scriptName})
            .then(this.#afterRequest);
    }

    status() {
        this
            .#request('status', {scriptName: this.#scriptName, code: this.controller.code})
            .then(this.#afterRequest)
    }

    exec() {
        BX.UI.Dialogs.MessageBox.confirm("Запуск скрипта в синхронном режиме приведет к блокировке сервера до тех пор, пока скрипт не будет выполнен", "Вы уверены?", () => {
            BX.UI.Dialogs.MessageBox.alert("Эта страница сама перезагрузится после того, как работа скрипта прекратиться", "Скрипт запущен");
        }, "Выполнить сейчас");
    }

    async #request(action, data) {
        return new Promise((resolve, reject) => {
            BX.ajax.runComponentAction('aspect:script.view', action, {
                mode: 'ajax',
                data: data || {}
            }).then((response) => {
                if (response.status === 'success') {
                    resolve(response.data)
                } else {
                    reject(response.errors)
                }
            }, reject)
        })
    }

}

class AspectScriptViewController {

    #dynamic;
    #code;

    constructor(containerId, scriptName) {
        this.containerId = containerId;
        this.#dynamic = (html) => {
            document.getElementById(containerId).querySelector('.aspect-code__dynamic').innerHTML = html;
        };

        this.#code = () => {
            return document.getElementById(containerId).querySelector('[name="code"]').value;
        }

        this.action = new AspectScriptViewAction(scriptName, this);
        this.#init();
        this.#events();
    }

    get code() {
        return this.#code();
    }

    #init() {
        BX.ready(() => {
            BX.UI.Hint.init(BX(this.containerId))
        })
    }

    #events() {
        setInterval(() => {
            this.action.status();
        }, 5000);
    }

    updateView(content) {
        this.#dynamic(content);
        this.#init()
    }
}