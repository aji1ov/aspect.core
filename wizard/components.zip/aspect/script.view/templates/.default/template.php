<?php

use Bitrix\Main\UI\Extension;

CCodeEditor::Show([
    'id' => 'code',
    'textareaId' => 'code',
    'height' => 350,
    'forceSyntax' => 'php',
]);

Extension::load('ui.buttons');
Extension::load("ui.hint");
Extension::load("ui.alerts");
Extension::load("ui.label");
Extension::load("ui.dialogs.messagebox");



?>
<div id="aspect-code" class="aspect-code">

    <div class="aspect-code__input">
        <textarea cols="60" name="code" id="code" rows="45" wrap="OFF" style="width:100%;"><?php echo htmlspecialcharsbx($arResult['CONTEXT']); ?></textarea>
    </div>

    <div class="aspect-code__dynamic">
        <?php include 'dynamic.php'?>
    </div>
</div>


<script type="text/javascript">
    window.aspectScriptViewController = new AspectScriptViewController('aspect-code', '<?=$arResult['NAME']?>');
</script>