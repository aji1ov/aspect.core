<?php

namespace Aspect\Component;

use Aspect\Lib\Facade\Command;
use Aspect\Lib\Facade\Yakov;
use Aspect\Lib\Manager\ScriptManager;
use Aspect\Lib\Preset\Command\Script\Start;
use Aspect\Lib\Service\Console\Color;
use CBitrixComponent;
use Exception;

class AspectScriptViewComponent extends CBitrixComponent
{

    /**
     * @throws Exception
     */
    public function prepareScriptData(): void
    {
        $scriptName = $this->arParams['NAME'];
        if (!$scriptName) LocalRedirect("/bitrix/admin/aspect_script_list.php");

        $scriptPath = Yakov::getCmdBundlesPath() . $scriptName . ".php";
        if (!file_exists($scriptPath)) LocalRedirect("/bitrix/admin/aspect_script_list.php");

        $scriptInfo = ScriptManager::getInstance()->get($scriptName);

        $this->arResult = [
            'NAME' => $scriptName,
            'PATH' => $scriptPath,
            'CONTEXT' => file_get_contents($scriptPath),
            'OUTPUT' => Color::clean($scriptInfo[ScriptManager::SCRIPT_OUTPUT]),
            'CREATED' => Command::inQueue(Start::class, ['name' => $scriptName]),
            'RUNNING' => $scriptInfo[ScriptManager::RUNNING_FLAG],
            'CANCELLED' => $scriptInfo[ScriptManager::CANCELLED_FLAG]
        ];
    }

    /**
     * @throws Exception
     */
    public function executeComponent(): void
    {
        $this->prepareScriptData();
        $this->includeComponentTemplate('template');

    }
}