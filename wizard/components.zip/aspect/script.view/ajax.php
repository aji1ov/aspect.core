<?php

namespace Aspect\Component;


use Aspect\Lib\Facade\Command;
use Aspect\Lib\Facade\Yakov;
use Aspect\Lib\Manager\ScriptManager;
use Aspect\Lib\Preset\Command\Script\Start;
use Bitrix\Main\Engine\Controller;
use Exception;

class AspectScriptViewController extends Controller
{
    public function configureActions()
    {
        return [
            'status' => [
                'prefilters' => []
            ]
        ];
    }

    /**
     * @throws Exception
     */
    public function statusAction(string $scriptName, string $code): array
    {
        $this->updateScript($scriptName, $code);
        return $this->updateView($scriptName);
    }

    /**
     * @throws Exception
     */
    public function makeAction(string $scriptName, string $code): array
    {
        $this->updateScript($scriptName, $code);
        Command::later(Start::class, ['name' => $scriptName], now());
        return $this->updateView($scriptName);
    }

    /**
     * @throws Exception
     */
    public function remakeAction(string $scriptName, string $code): array
    {
        $this->updateScript($scriptName, $code);
        ScriptManager::getInstance()->cancel($scriptName);
        Command::later(Start::class, ['name' => $scriptName], now());
        return $this->updateView($scriptName);
    }

    /**
     * @throws Exception
     */
    public function interruptAction(string $scriptName): array
    {
        ScriptManager::getInstance()->cancel($scriptName);
        return $this->updateView($scriptName);
    }

    private function updateScript(string $scriptName, string $code): void
    {
        file_put_contents(Yakov::getCmdBundlesPath().$scriptName.".php", $code);
    }

    /**
     * @throws Exception
     */
    public function updateView(string $scriptName): array
    {
        \CBitrixComponent::includeComponentClass('aspect:script.view');
        $component = new AspectScriptViewComponent();
        $component->initComponent('aspect:script.view');
        $component->arParams = [
            'NAME' => $scriptName
        ];

        $component->prepareScriptData();

        ob_start();
        $component->includeComponentTemplate('dynamic');
        return ['html' => ob_get_clean()];
    }


}