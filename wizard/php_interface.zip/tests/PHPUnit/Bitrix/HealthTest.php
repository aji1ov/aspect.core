<?php

namespace Bitrix;

use Aspect\App\TestJob;
use Aspect\Lib\Application;
use Aspect\Lib\Context;
use Aspect\Lib\Gateway;
use Aspect\Lib\PhpUnit\AspectTestCase;
use Aspect\Lib\Preset\Command\Help;
use Aspect\Lib\Preset\Command\Queue\All;
use Bitrix\Main\Loader;
use Bitrix\Main\LoaderException;
use PHPUnit\Framework\Attributes\RunInSeparateProcess;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class HealthTest extends AspectTestCase
{

    #[RunInSeparateProcess]
    public function testBitrixCore()
    {
        $this->assertInstanceOf(Main\Application::class, Main\Application::getInstance(), "Bitrix core is broken");
    }

    /**
     * @throws LoaderException
     */
    #[RunInSeparateProcess]
    public function testAspectModule()
    {
        $this->assertTrue(Loader::includeModule('aspect.core'), "Aspect module is not installed");
        $this->assertInstanceOf(Application::class, Application::getInstance(), "Aspect application is broken");
        $this->assertEquals(Gateway::CLI, Application::getInstance()->gateway(), "Incorrect gateway");
        $this->assertEquals(Context::TEST, Application::getInstance()->context(), 'Bad context');
    }

    #[RunInSeparateProcess]
    public function testAgentFaker()
    {
        $agentFaker = $this->faker()->legacy()->agents();
        $agentFaker->expect('doNothing();');
        $agentFaker->allow('runFakeAgent();')->override(function () {
            global $fakerAgentDone;
            $fakerAgentDone = true;
        });

        $agentId = \CAgent::AddAgent('runFakeAgent();', 'main');
        \CAgent::AddAgent('doNothing();', 'main');


        global $fakerAgentDone;
        $this->assertTrue($fakerAgentDone, 'Fake agent was not watched');
        $this->assertEquals(1, $agentId, 'Fake agent has incorrect id');
        $this->assertEquals(1, $agentFaker->calls('runFakeAgent();'), 'Too many agent additions');
    }

    public function testCommandFaker()
    {
        $commandFaker = $this->faker()->commands();
        $commandFaker->allow(Help::class)->override(function(InputInterface $input, OutputInterface $output) {
            $output->write('Fake!');
        });

        $commandFaker->expect(All::class);

        $output = command('help', ['command' => 'help']);
        command(All::class);

        $this->assertEquals('Fake!', $output, 'Bad command faker');
        $commandFaker->assertCalls(Help::class);
    }

    public function testQueueFaker()
    {
        $faked = false;

        $job = new TestJob('123');

        $queueFaker = $this->faker()->queue();
        $queueFaker->allow(TestJob::class)->override(function () use (&$faked){
            $faked = true;
        });

        queue($job);

        $this->assertTrue($faked);
    }
}