<?php

notice("running, wait 10 secs...");
sleep(10);
notice("done!");