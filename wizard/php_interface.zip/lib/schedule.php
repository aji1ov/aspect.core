<?php

use Aspect\Lib\Facade\Schedule;
use Aspect\Lib\Preset\Background\HealthJob;

return [
    Schedule::job(HealthJob::class)->description('Health check job')->period("*/15 * * * *")
];
