<?php

namespace Aspect\App\Event;

use Aspect\Lib\Application;
use Aspect\Lib\Blueprint\Event\ArrayEvent;
use Aspect\Lib\Event\EventPackage;
use Aspect\Lib\Event\ListEventSource;

class Iblock extends EventPackage
{
    #[ArrayEvent]
    public function OnBeforeIblockElementAdd(ListEventSource $source, Application $app): void
    {
    }
}