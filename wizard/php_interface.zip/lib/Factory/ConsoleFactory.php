<?php

namespace Aspect\App\Factory;

use Aspect\Lib\Application;
use Aspect\Lib\Service\Console\CommandDispatcher;
use Aspect\Lib\Service\DI\Factory;
use Aspect\Lib\Service\Pretty\Exception;
use Aspect\Lib\Service\Pretty\Exception\Cli;
use Aspect\Lib\Service\ScriptManager\LoopScriptManager;
use Aspect\Lib\Service\ScriptProcess\ProcOpenScriptProcess;
use Aspect\Lib\Support\Interfaces\CommandDispatcherInterface;
use Aspect\Lib\Support\Interfaces\ScriptManagerInterface;
use Aspect\Lib\Support\Interfaces\ScriptProcessInterface;
use Symfony\Component\Console\Input\ArgvInput;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\ConsoleOutput;
use Symfony\Component\Console\Output\OutputInterface;
use function Aspect\Lib\DI\singleton;

class ConsoleFactory implements Factory
{

    public function bind(): array
    {
        return [
            CommandDispatcherInterface::class => singleton(fn (Application $app) => $app->get(CommandDispatcher::class)),
            InputInterface::class => function() {
                global $argv;

                $arguments = $argv;
                array_shift($arguments);

                return new ArgvInput($arguments);
            },
            OutputInterface::class => new ConsoleOutput(),
            Exception::class => singleton(fn (Application $app) => $app->get(Cli::class)),
            ScriptManagerInterface::class => fn (Application $app) => $app->get(LoopScriptManager::class),
            ScriptProcessInterface::class => fn (Application $app) => $app->get(ProcOpenScriptProcess::class),
        ];
    }
}