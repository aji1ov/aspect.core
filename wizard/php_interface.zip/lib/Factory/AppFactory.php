<?php

namespace Aspect\App\Factory;

use Aspect\Lib\Application;
use Aspect\Lib\Context;
use Aspect\Lib\Service\DI\Factory;
use Bitrix\Main\DB\Connection;
use Symfony\Component\Lock\PersistingStoreInterface;
use Symfony\Component\Lock\Store\FlockStore;
use Symfony\Component\Lock\Store\SemaphoreStore;
use function Aspect\Lib\DI\singleton;

class AppFactory implements Factory
{

    public function bind(): array
    {
        return [
            Connection::class => \Bitrix\Main\Application::getConnection(),
            PersistingStoreInterface::class => function () {
                if(\extension_loaded('sysvsem')) {
                    return new SemaphoreStore();
                } else {
                    return new FlockStore();
                }
            }
        ];
    }
}