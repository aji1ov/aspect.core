<?php

namespace Aspect\App\Factory;

use Aspect\Lib\Application;
use Aspect\Lib\Context;
use Aspect\Lib\Service\DI\Factory;
use Aspect\Lib\Service\NoticeFormatter\PrintRNoticeFormatter;
use Aspect\Lib\Service\Noticer\CliNoticer;
use Aspect\Lib\Service\Noticer\InLogNoticer;
use Aspect\Lib\Service\Noticer\MutedNotifier;
use Aspect\Lib\Service\Noticer\PreTagNoticer;
use Aspect\Lib\Support\Interfaces\NoticeFormatterInterface;
use Aspect\Lib\Support\Interfaces\NoticerInterface;
use Bitrix\Main\Diag\FileLogger;
use Psr\Log\LoggerInterface;
use function Aspect\Lib\DI\singleton;

class LoggerFactory implements Factory
{

    public function bind(): array
    {
        return [
            LoggerInterface::class => function (Context $context) {
                return new FileLogger($_SERVER['DOCUMENT_ROOT'] . '/local/php_interface/logs/'.$context->value.'.log.txt');
            },
            NoticeFormatterInterface::class => singleton(fn (Application $app) => $app->get(PrintRNoticeFormatter::class)),

            NoticerInterface::class => function (Application $app) {
                return match ($app->context()) {
                    Context::TEST => $app->get(MutedNotifier::class),
                    Context::WEB => $app->get(PreTagNoticer::class),
                    Context::CLI => $app->get(CliNoticer::class),
                    default => $app->get(InLogNoticer::class)
                };
            },
        ];
    }
}