<?php

namespace Aspect\App\Factory;

use Aspect\Lib\Service\DI\Factory;
use Aspect\Lib\Transport\BlueprintTransport;
use Aspect\Lib\Transport\Converter\DateTimeConverter;
use Aspect\Lib\Transport\DtoBlueprint;
use Aspect\Lib\Transport\TransportInterface;
use DateTime;

class DtoFactory implements Factory
{
    public function bind(): array
    {

        DtoBlueprint::setConverter(DateTime::class, new DateTimeConverter('j.m.Y H:i:s'));

        return [
            TransportInterface::class => BlueprintTransport::class
        ];
    }
}