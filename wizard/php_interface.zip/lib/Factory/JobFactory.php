<?php

namespace Aspect\App\Factory;

use Aspect\Lib\Application;
use Aspect\Lib\Service\Background\Executor\SqlScheduleExecutor;
use Aspect\Lib\Service\Background\Dispatcher\SqlJobDispatcher;
use Aspect\Lib\Service\DI\Factory;
use Aspect\Lib\Support\Interfaces\JobDispatcherInterface;
use Aspect\Lib\Support\Interfaces\ScheduleExecutorInterface;
use function Aspect\Lib\DI\singleton;

class JobFactory implements Factory
{

    public function bind(): array
    {
        return [
            JobDispatcherInterface::class => singleton(fn (Application $app) => $app->get(SqlJobDispatcher::class)),
            ScheduleExecutorInterface::class => singleton(fn (Application $app) => $app->get(SqlScheduleExecutor::class)),
        ];
    }
}