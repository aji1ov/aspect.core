<?php

namespace Aspect\App\Factory\User;

use Aspect\Lib\Service\DI\Factory;

class GroupFactory implements Factory
{

    public function bind(): array
    {
        return [];
    }
}