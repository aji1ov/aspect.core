<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
{
	die();
}

return [
	'css' => 'dist/script.bundle.css',
	'js' => 'dist/script.bundle.js',
	'rel' => [
		'main.polyfill.core',
		'aspect.route',
		'ui.dialogs.messagebox',
	],
	'skip_core' => true,
];
