import {route} from "aspect.route";
import { MessageBox, MessageBoxButtons } from 'ui.dialogs.messagebox';

const getCreateForm = route().component('aspect:script.list').type('ajax').action('getCreateForm');
const create = route().component('aspect:script.list').type('ajax').action('create');

const newScriptAction = async (template) => {
	const response = await getCreateForm.request({
		template: template,
		argumentMap: {}
	})

	const box = new BX.UI.Dialogs.MessageBox({
		message: response.html,
		buttons: MessageBoxButtons.OK_CANCEL,
		okCaption: 'Создать',
		popupOptions: {
			bindElement: BX("yesnocancel"),
			offsetLeft: 20,
			closeIcon: false,
		},
		onOk: function() {
			const name = box.popupWindow.contentContainer.querySelector('[name="name"]').value;

			if(!name) {
				box.close();
				return;
			}

			create.request({name}).then(() => {
				location.reload()
			})
		}
	});

	box.show();

}

export {
	newScriptAction
};