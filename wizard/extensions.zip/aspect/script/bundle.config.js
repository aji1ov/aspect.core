module.exports = {
	input: 'src/script.js',
	output: 'dist/script.bundle.js',
	namespace: 'BX.Aspect',
};
