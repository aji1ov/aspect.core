module.exports = {
	input: 'src/route.js',
	output: 'dist/route.bundle.js',
	namespace: 'BX.Aspect',
	minification: false,
};
