class ComponentRouter {

    #name

    constructor(name) {
        this.#name = name;
    }

    get name () {
        return this.#name
    }

    type(type) {
        return new ComponentTypeRouter(this.#name, type)
    }
}

class ComponentTypeRouter extends ComponentRouter {
    #type

    constructor(name, type) {
        super(name);
        this.#type = type;
    }

    get type() {
        return this.#type
    }

    action(action) {
        return new ComponentTypedActionRouter(this.name, this.#type, action)
    }
}

class ComponentTypedActionRouter extends ComponentTypeRouter {
    #action

    constructor(name, type, action) {
        super(name, type)
        this.#action = action
    }

    async request(data) {
        return new Promise((resolve, reject) => {
            BX.ajax.runComponentAction(this.name, this.#action, {
                mode: this.type,
                data: data || {}
            }).then((response) => {
                if (response.status === 'success') {
                    resolve(response.data)
                } else {
                    reject(response.errors)
                }
            }, reject)
        })
    }
}

class Router {
    component(name) {
        return new ComponentRouter(name)
    }
}

export const route = () => {
    return new Router()
}
